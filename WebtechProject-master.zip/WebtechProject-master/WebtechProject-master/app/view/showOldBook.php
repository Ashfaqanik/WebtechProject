<?php
	session_start();
	//print_r($_SESSION);
?>



				<?php include_once '../../includes/topHomepage.php'; ?>

        <?php include_once '../../includes/showOldBook.php' ?>


				 <?php include_once '../../includes/bottomHomepage.php'; ?>



	
