<?php
	session_start();
	//print_r($_SESSION);
?>

				<?php include '../../includes/topHomepage.php'; ?>
				<?php include 'scripts.php'; ?>

        		<?php include_once '../../includes/oldBooks.php' ?>


				 <?php include '../../includes/bottomHomepage.php'; ?>
