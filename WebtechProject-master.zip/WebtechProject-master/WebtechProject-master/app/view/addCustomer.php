<?php
	session_start();
?>


<?php

include_once '../../includes/topHomepage.php';
include_once '../../includes/addCustomer.php';
include_once '../../includes/bottomHomepage.php';

?>
