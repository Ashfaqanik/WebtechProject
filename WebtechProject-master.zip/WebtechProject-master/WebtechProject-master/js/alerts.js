function f1() {
  alert("hello");
}
